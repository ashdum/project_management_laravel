import { RealtimeChannel } from '@supabase/supabase-js';
import { supabase } from '../supabase';
import { useBoardStore } from '../../store';
import { Card, Column, Dashboard } from '../../types';

export class RealtimeManager {
  private channels: Map<string, RealtimeChannel> = new Map();

  subscribeToDashboard(dashboardId: string) {
    if (this.channels.has(dashboardId)) {
      return;
    }

    if (!supabase) {
      console.warn('Supabase client not initialized');
      return;
    }

    const channel = supabase.channel(`dashboard:${dashboardId}`)
      .on('presence', { event: 'sync' }, () => {
        const state = channel.presenceState();
        console.log('Presence state:', state);
      })
      .on('presence', { event: 'join' }, ({ key, newPresences }) => {
        console.log('User joined:', key, newPresences);
      })
      .on('presence', { event: 'leave' }, ({ key, leftPresences }) => {
        console.log('User left:', key, leftPresences);
      })
      .on('broadcast', { event: 'card:update' }, ({ payload }) => {
        this.handleCardUpdate(payload);
      })
      .on('broadcast', { event: 'card:move' }, ({ payload }) => {
        this.handleCardMove(payload);
      })
      .on('broadcast', { event: 'column:update' }, ({ payload }) => {
        this.handleColumnUpdate(payload);
      })
      .on('broadcast', { event: 'column:move' }, ({ payload }) => {
        this.handleColumnMove(payload);
      });

    channel.subscribe(async (status) => {
      if (status === 'SUBSCRIBED') {
        const presenceTrackStatus = await channel.track({
          user_id: 'user-1', // Replace with actual user ID
          online_at: new Date().toISOString(),
        });
        console.log('Presence track status:', presenceTrackStatus);
      }
    });

    this.channels.set(dashboardId, channel);
  }

  unsubscribeFromDashboard(dashboardId: string) {
    const channel = this.channels.get(dashboardId);
    if (channel) {
      channel.unsubscribe();
      this.channels.delete(dashboardId);
    }
  }

  private handleCardUpdate(payload: { 
    dashboardId: string;
    columnId: string;
    card: Card;
  }) {
    const store = useBoardStore.getState();
    store.updateCard(payload.columnId, payload.card.id, payload.card);
  }

  private handleCardMove(payload: {
    dashboardId: string;
    fromColumnId: string;
    toColumnId: string;
    fromIndex: number;
    toIndex: number;
  }) {
    const store = useBoardStore.getState();
    store.moveCard(
      payload.fromColumnId,
      payload.toColumnId,
      payload.fromIndex,
      payload.toIndex
    );
  }

  private handleColumnUpdate(payload: {
    dashboardId: string;
    column: Column;
  }) {
    const store = useBoardStore.getState();
    store.updateColumn(payload.column);
  }

  private handleColumnMove(payload: {
    dashboardId: string;
    columnIds: string[];
  }) {
    const store = useBoardStore.getState();
    store.updateColumnOrder(payload.dashboardId, payload.columnIds);
  }

  // Methods to broadcast changes
  broadcastCardUpdate(dashboardId: string, columnId: string, card: Card) {
    const channel = this.channels.get(dashboardId);
    channel?.send({
      type: 'broadcast',
      event: 'card:update',
      payload: { dashboardId, columnId, card },
    });
  }

  broadcastCardMove(
    dashboardId: string,
    fromColumnId: string,
    toColumnId: string,
    fromIndex: number,
    toIndex: number
  ) {
    const channel = this.channels.get(dashboardId);
    channel?.send({
      type: 'broadcast',
      event: 'card:move',
      payload: {
        dashboardId,
        fromColumnId,
        toColumnId,
        fromIndex,
        toIndex,
      },
    });
  }

  broadcastColumnUpdate(dashboardId: string, column: Column) {
    const channel = this.channels.get(dashboardId);
    channel?.send({
      type: 'broadcast',
      event: 'column:update',
      payload: { dashboardId, column },
    });
  }

  broadcastColumnMove(dashboardId: string, columnIds: string[]) {
    const channel = this.channels.get(dashboardId);
    channel?.send({
      type: 'broadcast',
      event: 'column:move',
      payload: { dashboardId, columnIds },
    });
  }
}

export const realtimeManager = new RealtimeManager();